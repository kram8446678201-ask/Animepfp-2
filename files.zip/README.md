# AnimeVault — Setup Guide

## Files in this folder
- `index.html` — Public gallery (log dekhenge + download karenge)
- `admin.html` — Tumhara admin panel (tum images add/delete karoge)
- `data.json` — Sab assets ka data yahan store hoga

---

## Step 1: GitHub Repo banao

1. GitHub.com pe jao → **New Repository**
2. Repo name: `animevault` (ya jo chahiye)
3. **Public** rakho
4. **Initialize with README** check karo
5. Create repository

---

## Step 2: Files upload karo

1. Repo mein jao → **Add file → Upload files**
2. Teen files drag karo: `index.html`, `admin.html`, `data.json`
3. Commit changes

---

## Step 3: GitHub Pages ON karo

1. Repo → **Settings → Pages**
2. Source: **Deploy from a branch**
3. Branch: **main** / root
4. Save karo
5. ~2 min baad site live ho jayegi:  
   `https://YOUR_USERNAME.github.io/animevault/`

---

## Step 4: Admin ke liye Token banao

1. GitHub → **Settings → Developer settings → Personal access tokens → Tokens (classic)**
2. **Generate new token (classic)**
3. Note: `animevault admin`
4. Expiration: 90 days ya No expiration
5. Scopes: sirf **`repo`** checkbox tick karo
6. Generate → **Token copy kar lo** (ek baar hi dikhega)

---

## Step 5: index.html mein username update karo

`index.html` file kholo, top pe ye 2 lines change karo:

```js
const GITHUB_USER = 'YOUR_GITHUB_USERNAME';  // apna GitHub username
const GITHUB_REPO = 'animevault';             // apna repo name
```

File save karke GitHub pe dobara upload karo.

---

## Step 6: Admin panel use karo

1. `https://YOUR_USERNAME.github.io/animevault/admin.html` pe jao
2. Password: `animevault2026`  
   *(admin.html mein `ADMIN_PASSWORD` change kar sakte ho)*
3. GitHub Config mein bharo:
   - GitHub Username
   - Repo Name
   - Personal Access Token
4. **Save Config** click karo

---

## Asset kaise add karein

1. Image ko **Imgur** (imgur.com) ya **Catbox** (catbox.moe) pe upload karo — free hai
2. Direct image link copy karo (`.jpg` / `.webp` / `.png` end hona chahiye)
3. Admin panel → form bharo → **Add to Gallery**
4. ~1 minute mein public site pe dikhe ga

---

## Password change karna hai?

`admin.html` file mein:
```js
const ADMIN_PASSWORD = 'animevault2026';  // yahan change karo
```

---

## Free Image Hosting Options

| Site | URL | Notes |
|------|-----|-------|
| Imgur | imgur.com | Most reliable |
| Catbox | catbox.moe | No compression |
| GitHub itself | Raw file URL | Best quality |

GitHub pe directly images store karna (recommended for best quality):
1. Repo mein `images/` folder banao
2. Images upload karo
3. File click karo → **Download** → URL copy karo
4. URL mein `blob` ko `raw` se replace karo

---

## Support
Koi problem ho toh data.json manually edit bhi kar sakte ho GitHub pe directly.
